package com.zhiyi.ukafu.data;

/**
 * Created by Administrator on 2018/10/14.
 */

public class LogItem {
    public int id;
    public String log_value;
    public int log_type;
    public String create_dt;
}
