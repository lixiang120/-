package com.zhiyi.ukafu;

import android.os.Message;

/**
 * Created by Administrator on 2018/8/7.
 */

public interface IMessageHander {
    void handMessage(Message msg);
}
