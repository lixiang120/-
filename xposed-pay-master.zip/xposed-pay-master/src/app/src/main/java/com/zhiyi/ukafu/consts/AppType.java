package com.zhiyi.ukafu.consts;

/**
 * Created by Administrator on 2019/5/2.
 */

public class AppType {
    public static final String BANK = "BANK";
    public static final String LEFSMS = "LEFSMS";
}
