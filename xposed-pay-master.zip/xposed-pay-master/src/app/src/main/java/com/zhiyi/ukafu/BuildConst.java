package com.zhiyi.ukafu;

/**
 *
 * 编译常量
 *  */
public class BuildConst {
    /**
     * 加密密钥
     * */
    public static final String Secret="9470054f-3671-467b-bf31-8c9244c8b781";

    public static final String BuglyId="ff0995764e";
}
