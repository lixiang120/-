package com.zhiyi.ukafu.activitys;

import android.content.Context;
import android.webkit.WebView;

public class MPageView extends WebView {

    public MPageView(Context context) {
        super(context);
    }


}
